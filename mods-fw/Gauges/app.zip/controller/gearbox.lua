-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- Gauges Mod
-- Gearbox Controller
------------------------------------------------------------*/

local name = 'Gauges_Controller_gearbox';
local _ = newclass(name, Controller);
_G[name] = _;

function _:init()
	self.super:init();
end;

function _:load()
	self.config = Mods:getRegistry(self.ControllerPrefix, 'config');	
	-- Gearbox Settings 
	self.gearboxSettings = {}
	self.gearboxSettings.gearboxMode			= Utils.getNoNil(self.config:getValue('config.gearboxMode', 'string'), 'manual');
	self.gearboxSettings.driveMode				= 1;
	self.gearboxSettings.maxGear				= Utils.getNoNil(self.config:getValue('config.maxGear', 'integer'), 4);
	self.gearboxSettings.currentGear			= 'N';
	self.gearboxSettings.clutchPedal			= false;
	self.gearboxSettings.gearboxFinalRatio		= Utils.getNoNil(self.config:getValue('config.gearboxFinalRatio', 'float'), 0.5);
	
	if self.gearboxSettings.gearboxMode ~= 'manual' and self.gearboxSettings.gearboxMode ~= 'auto' then self.gearboxSettings.gearboxMode = 'manual' end;
	if self.gearboxSettings.maxGear>9 then self.gearboxSettings.maxGear = 9 
	elseif self.gearboxSettings.maxGear<1 then self.gearboxSettings.maxGear = 1 end;
	if self.gearboxSettings.gearboxFinalRatio>1 then self.gearboxSettings.gearboxFinalRatio = 1 
	elseif self.gearboxSettings.gearboxFinalRatio<0 then self.gearboxSettings.gearboxFinalRatio = 0 end;	
	
	Mods:setRegistry(self.ControllerPrefix, 'gearboxSettings', self.gearboxSettings);
	Mods:setRegistry(self.ControllerPrefix, 'globalGearboxMaxGear', self.gearboxSettings.maxGear);	
	Mods:setRegistry(self.ControllerPrefix, 'globalGearboxFinalRatio', self.gearboxSettings.gearboxFinalRatio);	

	-- Model
	self:setModel('gearboxSpecialization');
	self:setModel('manualIgnition');

	-- Views
	local view = self:setView();
	Mods:setRegistry(self.ControllerPrefix, 'view', view);		
end;

function _:loadSpecialization()
	if (g_currentMission.controlledVehicle ~= nil and g_currentMission.controlledVehicle.gearboxSpecializationLoaded == nil) then
		local spec = gearboxSpec();
		table.insert(g_currentMission.controlledVehicle.specializations, spec);
		spec:load(g_currentMission.controlledVehicle, self.ControllerPrefix);
	end;
end;