-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- Gauges Mod
-- Initialization
------------------------------------------------------------*/

Gauges_Mod = newclass("Gauges_Mod");

function Gauges_Mod:init(modName)
end;

function Gauges_Mod:load()
	self.rpmController 	 		= MVC_:getInstance(self.modName, 'rpm');
	self.gearboxController 	 	= MVC_:getInstance(self.modName, 'gearbox');
end;