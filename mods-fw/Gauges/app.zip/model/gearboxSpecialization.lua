-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- Gauges Mod
-- Specialization Gearbox
------------------------------------------------------------*/

-- Model
local name = 'Gauges_Model_gearboxSpecialization';
local _ = newclass(name, Model);
_G[name] = _;

function _:init()
end;

function _:load()
end;


-- Specialization
gearboxSpecHelper = {}
gearboxSpecHelper.SpecInstances = {}

function gearboxSpecHelper:getInstance(index)
	if self.SpecInstances[index] == nil then
		self.SpecInstances[index] = {};
	end;	
	return self.SpecInstances[index];
end;


gearboxSpec = newclass('gearboxSpec');

function gearboxSpec:init()
end;

function gearboxSpec:load(Vehicle, modName)
	if Vehicle ~= nil and tonumber(Vehicle) == nil then
		g_currentMission.controlledVehicle.gearboxSpecializationLoaded = true;
		local this = gearboxSpecHelper:getInstance(Vehicle.rootNode);
		
		this.modName = modName;
		this.Vehicle = Vehicle;
		
		this.view					= Mods:getRegistry(this.modName, 'view');
		this.input 					= Mods:getRegistry(this.modName, 'input');
		this.GearsGaugeWindow 		= Mods:getRegistry(this.modName, 'GearsGaugeWindow');
		this.GearD 					= Mods:getRegistry(this.modName, 'GearD');
		this.GearN 					= Mods:getRegistry(this.modName, 'GearN');
		this.GearR 					= Mods:getRegistry(this.modName, 'GearR');
		this.Gear1 					= Mods:getRegistry(this.modName, 'Gear1');
		this.Gear2 					= Mods:getRegistry(this.modName, 'Gear2');
		this.Gear3 					= Mods:getRegistry(this.modName, 'Gear3');
		this.Gear4 					= Mods:getRegistry(this.modName, 'Gear4');
		this.Gear5 					= Mods:getRegistry(this.modName, 'Gear5');
		this.Gear6 					= Mods:getRegistry(this.modName, 'Gear6');
		this.Gear7 					= Mods:getRegistry(this.modName, 'Gear7');
		this.Gear8 					= Mods:getRegistry(this.modName, 'Gear8');
		this.Gear9 					= Mods:getRegistry(this.modName, 'Gear9');
		this.rpmLightOff 			= Mods:getRegistry(this.modName, 'rpmLightOff');
		this.rpmLightOn 			= Mods:getRegistry(this.modName, 'rpmLightOn');
		this.gearboxModeCaption 	= Mods:getRegistry(this.modName, 'gearboxModeCaption');
		this.lightRoad 				= Mods:getRegistry(this.modName, 'lightRoad');
		this.lightField 			= Mods:getRegistry(this.modName, 'lightField');
		this.lightFuelOff 			= Mods:getRegistry(this.modName, 'lightFuelOff');
		this.lightFuelOn 			= Mods:getRegistry(this.modName, 'lightFuelOn');
		this.lightBatteryOff 		= Mods:getRegistry(this.modName, 'lightBatteryOff');
		this.lightBatteryOn			= Mods:getRegistry(this.modName, 'lightBatteryOn');		
		
		this.gearboxSettings 			= Mods:getRegistry(this.modName, 'gearboxSettings');
		this.globalGearboxMaxGear		= Mods:getRegistry(this.modName, 'globalGearboxMaxGear');	
		this.globalGearboxFinalRatio	= Mods:getRegistry(this.modName, 'globalGearboxFinalRatio');	

		this.originalValues 										= {}
		this.originalValues.maxAccelerationSpeed					= Vehicle.maxAccelerationSpeed;
		this.originalValues.motor									= {}
		this.originalValues.motor.forwardGearRatios					= {}
		this.originalValues.motor.forwardGearRatiosStandard			= {}
		this.originalValues.motor.forwardGearRatios[3]				= Vehicle.motor.forwardGearRatios[3];
		this.originalValues.motor.forwardGearRatiosStandard[3]		= Vehicle.motor.forwardGearRatios[3];
		this.originalValues.motor.backwardGearRatio					= Vehicle.motor.backwardGearRatio;
		this.originalValues.motor.transmissionEfficiency		    = Vehicle.motor.transmissionEfficiency;
		this.originalValues.downForce								= Vehicle.downForce;
		
		function this:isAI()
			if this.Vehicle.isAITractorActivated ~= nil then
				return this.Vehicle.isAITractorActivated;
			elseif this.Vehicle.isAIThreshing ~= nil then
				return this.Vehicle.isAIThreshing;
			else return false end;
		end;
	end;
end;

function gearboxSpec:delete()
end;

function gearboxSpec:mouseEvent(posX, posY, isDown, isUp, button)
end;

function gearboxSpec:keyEvent(unicode, sym, modifier, isDown)
end;

function gearboxSpec:updateTick(dt)
	local this = gearboxSpecHelper:getInstance(self.rootNode);

	-- RPM physics
	if self.isMotorStarted and self.isEntered and not this:isAI() and self.motor.speedLevel == 0 then
		--if this.gearboxSettings.gearboxMode == 'manual' then
			if self.motor.minRpm<150 then self.motor.minRpm = 150 end;
			
			if self.motor.speedLevel == 0 then
				local newRPM = 0;
				if self.motor.lastMotorRpmForBrake == nil then self.motor.lastMotorRpmForBrake = self.motor.minRpm end;
								
				if this.neutralGearRPMprogress == nil then
					this.neutralGearRPMprogress = Controls.Progress(self.motor.maxRpm[3], 0.0, self.motor, 'lastMotorRpm');
				end;			
				-- Neutral gear
				if this.gearboxSettings.currentGear == 'N' then 
					if self.neutralGearReset then 
						self.motor.lastMotorRpm = self.motor.minRpm;
						this.neutralGearRPMprogress.lastValue = self.motor.minRpm;
					end;
					local acceleration = 0;
					if InputBinding.isAxisZero(-InputBinding.getAnalogInputAxis(InputBinding.AXIS_MOVE_FORWARD_VEHICLE)) then
						acceleration = -InputBinding.getDigitalInputAxis(InputBinding.AXIS_MOVE_FORWARD_VEHICLE);
					else 
						acceleration = -InputBinding.getAnalogInputAxis(InputBinding.AXIS_MOVE_FORWARD_VEHICLE);
					end;
					this.neutralGearRPMprogress:start();
					local targetValue = self.motor.maxRpm[3]*acceleration;
					if targetValue<self.motor.minRpm then targetValue = self.motor.minRpm-10 end;
					this.neutralGearRPMprogress:setTargetValue(targetValue);
					if acceleration>0 then this.neutralGearRPMprogress:setProgressSpeed(acceleration*10);
					else this.neutralGearRPMprogress:setProgressSpeed(1.0) end;
					self.lastAcceleration = acceleration*0.5;
					if this.neutralGearRPMprogress:getLastValue() ~= nil then self.motor.lastMotorRpm = this.neutralGearRPMprogress:getLastValue() end;
					if self.motor.lastMotorRpm<self.motor.minRpm then self.motor.lastMotorRpm = self.motor.minRpm end;
					self.neutralGearReset = false;
				-- Other gears
				else 
					self.neutralGearReset = true;
					this.neutralGearRPMprogress:stop();
					if self.lastAccelerationForBrake == nil then self.lastAccelerationForBrake = 0 end; 
					if self.lastAcceleration<0 and this.gearboxSettings.gearboxMode == 'auto' then newRPM = -self.lastAcceleration*self.motor.maxRpm[3]; 
					else
						-- Brake
						if self.lastAcceleration<0 then
							if this.gearboxSettings.currentGear == 'R' and self.wheels[1].axleSpeed>0 then 
								newRPM = self.lastAcceleration*self.motor.maxRpm[3];
								self.lastAcceleration = 0;
								self.motor.lastMotorRpmForBrake = self.motor.minRpm;
							else
								newRPM = (1-(-self.lastAcceleration))*self.motor.lastMotorRpmForBrake;
								self.lastAccelerationForBrake = newRPM/self.motor.maxRpm[3];
								self.lastAcceleration = self.lastAcceleration*1.15;
							end;
						-- Acceleration
						else
							if self.lastAccelerationForBrake>0 then 
								self.lastAcceleration = self.lastAccelerationForBrake;
								self.lastAccelerationForBrake = 0;
							end;
							newRPM = self.lastAcceleration*self.motor.maxRpm[3];
						end;
					end;
					
					if newRPM<self.motor.minRpm then newRPM = self.motor.minRpm
					elseif newRPM>self.motor.maxRpm[3] then newRPM = self.motor.maxRpm[3] end;	
					self.motor.lastMotorRpm = newRPM;
					if self.lastAcceleration>0 then self.motor.lastMotorRpmForBrake = self.motor.lastMotorRpm end;
				end;
				
				-- Clutch		;
				if this.gearboxSettings.clutchPedal and tonumber(this.gearboxSettings.currentGear) ~= nil then
					if tonumber(this.gearboxSettings.currentGear)>=1 then						
						local gearboxFinalRatio = 1-this.gearboxSettings.gearboxFinalRatio;
						if gearboxFinalRatio>0.65 then gearboxFinalRatio = 0.65
						elseif gearboxFinalRatio<0.35 then gearboxFinalRatio = 0.35 end;
						--local newAcceleration = gearboxFinalRatio+((1-gearboxFinalRatio)*tonumber(this.gearboxSettings.currentGear-1)/this.gearboxSettings.maxGear);
						local newAcceleration = 0.3+((1-gearboxFinalRatio)*tonumber(this.gearboxSettings.currentGear-1)/this.gearboxSettings.maxGear);
						if newAcceleration<self.lastAcceleration then
							self.lastAcceleration = newAcceleration;
						end;
					end;
				end;
			end;
			
			if self.lastAccelerationInDraw ~= nil then
				if self.lastAccelerationInDraw>self.lastAcceleration then self.deceleration = true
				else self.deceleration = false end;
			else self.deceleration = false end;
			
			if self.wheelsNotGroundContactNum ~= nil then
				self.wheelsNotGroundContactNumTick = self.wheelsNotGroundContactNum;
			end;
	end;
	
	-- Speed physics
	if self.isMotorStarted and self.isEntered then
		if this.gearboxSettings.gearboxMode == 'manual' then
			if self.motor.speedLevel == 0 then
				this.originalValues.motor.forwardGearRatios[3] = this.originalValues.motor.forwardGearRatiosStandard[3]*this.gearboxSettings.gearboxFinalRatio*2;
				if this.gearboxSettings.gearboxFinalRatio>0.5 and tonumber(this.gearboxSettings.currentGear) ~= nil then
					self.motor.transmissionEfficiency = this.originalValues.motor.transmissionEfficiency*(1+this.gearboxSettings.gearboxFinalRatio/4)+(this.gearboxSettings.currentGear/15);
				end;
			end;
		end;
	end;
	
	 -- naprawa wstecznego na górce
	if self.isMotorStarted and self.isEntered and this.gearboxSettings.currentGear == 'R' and this.gearboxSettings.gearboxMode == 'manual' and self.movingDirection == 1 then 
		self.maxAccelerationSpeed 			= 0;
		self.motor.forwardGearRatios[3] 	= 0;
		self.motor.speedLevel				= 0;
		self.movingDirection 				= 0;
	end;
end;

function gearboxSpec:update(dt)
	local this = gearboxSpecHelper:getInstance(self.rootNode);

	if self.isMotorStarted and self.isEntered and not this:isAI() and self.motor.speedLevel == 0 then
		-- RPM Light
		local rpmTipSegment = self.motor.maxRpm[3]/9;
		if self.motor.lastMotorRpm>rpmTipSegment*8 then
			this.rpmLightOff.visible = false;
			this.rpmLightOn.visible	= true;
		else 
			this.rpmLightOff.visible = true;
			this.rpmLightOn.visible	= false;		
		end;
		-- Efekt "dygotania" licznika obrotów na odcięciu
		--[[if self.motor.speedLevel == 0 and self.motor.lastMotorRpm == self.motor.maxRpm[3] then
			self.motor.lastMotorRpm = rpmTipSegment*8.5;
		end;--]]
		
		
		-- Szybsze obroty gdy pojazd oderwie się od ziemi
		self.wheelsNotGroundContactNum = 0;
		for key,wheel in pairs(self.wheels) do 
			if not wheel.hasGroundContact then
				self.wheelsNotGroundContactNum = self.wheelsNotGroundContactNum+1;
			end;
		end;
		if self.wheelsNotGroundContactNum == 0 then self.lastAccelerationHasGroundContact = self.lastAcceleration end; -- ostatnia prędkość gdy koła dotykały ziemi
		if self.wheelsNotGroundContactNumTick ~= nil then -- podczas upadku
			if self.wheelsNotGroundContactNum == 0 and self.wheelsNotGroundContactNumTick>0 then
				self.lastAcceleration = self.lastAccelerationHasGroundContact*(1-self.fallDownForce); -- przyspieszenie spada w trakcie upadku
				if self.lastAcceleration<0.1 then self.lastAcceleration = 0.1 end;
			end;
		end;
		if self.wheelsNotGroundContactNum>0 then -- podczas oderwania od ziemi
			self.fallDownForce = self.fallDownForce+((0.001*self.wheelsNotGroundContactNum)*(1+(0.045*self.downForce))); -- obliczanie siły z jaką pojazd opada na ziemię
			if -InputBinding.getDigitalInputAxis(InputBinding.AXIS_MOVE_FORWARD_VEHICLE)>0 or -InputBinding.getAnalogInputAxis(InputBinding.AXIS_MOVE_FORWARD_VEHICLE)>0 then 
				self.lastAcceleration = self.lastAcceleration*(1+(0.01*self.fallDownForce)); -- przyspieszenie wzrasta w trakcie lotu
				if self.lastAcceleration>1 then self.lastAcceleration = 1 end;			
			end;
		else 
			self.fallDownForce = 0; -- siła opadania na ziemię równa zero
		end;
		
	
		-- Gearbox 
		if self.gearbox ~= nil then
			if self.gearbox.maxGear ~= nil then
				this.gearboxSettings.maxGear = tonumber(self.gearbox.maxGear);
				if this.gearboxSettings.maxGear>9 then this.gearboxSettings.maxGear = 9 
				elseif this.gearboxSettings.maxGear<1 then this.gearboxSettings.maxGear = 1 end;				
			else this.gearboxSettings.maxGear = this.globalGearboxMaxGear end;
			
			if self.gearbox.gearboxFinalRatio ~= nil then
				this.gearboxSettings.gearboxFinalRatio = tonumber(self.gearbox.gearboxFinalRatio);
				if this.gearboxSettings.gearboxFinalRatio>1 then this.gearboxSettings.gearboxFinalRatio = 1 
				elseif this.gearboxSettings.gearboxFinalRatio<0 then this.gearboxSettings.gearboxFinalRatio = 0.01 end;				
			else this.gearboxSettings.gearboxFinalRatio = this.globalGearboxFinalRatio end;			
		else 
			this.gearboxSettings.maxGear 				= this.globalGearboxMaxGear;
			this.gearboxSettings.gearboxFinalRatio 		= this.globalGearboxFinalRatio;
		end;
		this.gearboxSettings.gearboxFinalRatio = 0.5+((this.gearboxSettings.gearboxFinalRatio-0.5)*0.4);
		
		if tonumber(this.gearboxSettings.currentGear) ~= nil then
			if tonumber(this.gearboxSettings.currentGear)>tonumber(this.gearboxSettings.maxGear) then 
				this.view:setGear(this.gearboxSettings.maxGear);
			end;
		end;
		
		
		if this.gearboxSettings.gearboxMode == 'auto' then
			self.maxAccelerationSpeed 			= this.originalValues.maxAccelerationSpeed;
			self.motor.forwardGearRatios[3] 	= this.originalValues.motor.forwardGearRatios[3];
			self.motor.backwardGearRatio 		= this.originalValues.motor.backwardGearRatio;
			if self.movingDirection == -1 and self.wheels[1].axleSpeed<0 then 
				this.view:setGear('R');
			elseif this.gearboxSettings.currentGear == 'N' or (this.gearboxSettings.currentGear == 'R' and self.wheels[1].axleSpeed>=0) then
				this.view:setGear(1);
			end;
			
			-- Auto gear up
			if tonumber(this.gearboxSettings.currentGear)~= nil and self.motor.lastMotorRpm>rpmTipSegment*8  then
				this.view:upGear(true);
			end;
			-- Auto gear down
			if tonumber(this.gearboxSettings.currentGear)~= nil then
				local onePartRPM = self.motor.maxRpm[3]/this.gearboxSettings.maxGear;
				for i=2, this.gearboxSettings.maxGear, 1 do 
					if tonumber(this.gearboxSettings.currentGear)>i and self.motor.lastMotorRpm<onePartRPM*i and self.deceleration then
						this.view:downGear(true);
					end;
				end;
				if tonumber(this.gearboxSettings.currentGear)>1 and self.motor.lastMotorRpm<=self.motor.minRpm then this.view:setGear(1) end;
			end;			
		end;
		--elseif this.gearboxSettings.gearboxMode == 'manual' then
			-- Acceleration Speed
			if this.gearboxSettings.currentGear == 'N' then
				self.maxAccelerationSpeed 			= 0;
				self.motor.forwardGearRatios[3] 	= 0;
				self.motor.backwardGearRatio 		= 0;
				self.motor.speedLevel				= 0;
				self.movingDirection 				= 0;
			elseif this.gearboxSettings.currentGear == 'R' then
				if this.gearboxSettings.gearboxMode == 'manual' then
					self.maxAccelerationSpeed 			= this.originalValues.maxAccelerationSpeed;
					self.motor.forwardGearRatios[3] 	= -this.originalValues.motor.backwardGearRatio;
					if self.movingDirection == 1 then -- naprawa wstecznego na górce
						self.maxAccelerationSpeed 			= 0;
						self.motor.forwardGearRatios[3] 	= 0;
						self.motor.speedLevel				= 0;
						self.movingDirection 				= 0;
					else
						self.motor.backwardGearRatio 	= -this.originalValues.motor.backwardGearRatio;
					end;
					self.movingDirection 				= 0;
					self.motor.speedLevel 				= 0;				
				end;
			else
				if self.movingDirection == -1 then
					self.maxAccelerationSpeed = 0;
					self.motor.backwardGearRatio = 0;
				else
					self.movingDirection = 1;
					if tonumber(this.gearboxSettings.currentGear) ~= nil then				
						for i=1,this.gearboxSettings.maxGear do
							if tonumber(this.gearboxSettings.currentGear) == i then
								local accelerationRatio = this.gearboxSettings.gearboxFinalRatio*2;
								if accelerationRatio<0.35 then accelerationRatio = 0.35 end;
								--local minAcceleration = this.originalValues.maxAccelerationSpeed/(i*accelerationRatio*2); -- regulacja przyspieszania
								--local minAcceleration = this.originalValues.maxAccelerationSpeed/(i*accelerationRatio*0.5); -- regulacja przyspieszania
								local minAcceleration = this.originalValues.maxAccelerationSpeed/(i*accelerationRatio*((self.wheels[1].netInfo.y+self.wheels[2].netInfo.y+self.wheels[3].netInfo.y+self.wheels[4].netInfo.y)*0.15)); -- regulacja przyspieszania: rozmiar kół ma wpływ
								if this.gearboxSettings.driveMode == 0 then minAcceleration = minAcceleration*5 end; -- szybsze przyspieszanie na biegach terenowych
								if self.lastAcceleration>0 then self.maxAccelerationSpeed = minAcceleration*(1-self.lastAcceleration)
								else self.maxAccelerationSpeed = minAcceleration end;

								local basePartRatio = 20*this.originalValues.motor.forwardGearRatios[3]/100;
								local restPartRatio = this.originalValues.motor.forwardGearRatios[3]-basePartRatio;
								local onePartRatio = restPartRatio/this.gearboxSettings.maxGear;
								self.motor.forwardGearRatios[3] = basePartRatio+(onePartRatio*i); -- nowa wartość przełożeń skrzyni
								if self.driveway ~= nil then -- jeśli dodano specjalizacje drivewayPhysic uwzględnij w przełożeniach
									if this.gearboxSettings.driveMode == 0 then -- dla biegów terenowych
										self.motor.forwardGearRatios[3] = self.motor.forwardGearRatios[3] - self.driveway.power*0.05;
										if self.motor.forwardGearRatios[3]<basePartRatio*2 then self.motor.forwardGearRatios[3] = basePartRatio*2 end;
									else -- pozostałe
										self.motor.forwardGearRatios[3] = self.motor.forwardGearRatios[3] - self.driveway.power*1.5;
										if self.motor.forwardGearRatios[3]<basePartRatio then self.motor.forwardGearRatios[3] = basePartRatio end;
									end;
								end;
							end;
						end;						
					end;
				end;
			end;
		--end;
		if this.gearboxSettings.driveMode == 1 then	-- ustawienia biegów drogowych
			self.downForce = this.originalValues.downForce;
		elseif this.gearboxSettings.driveMode == 0 then
			local fieldDriveRatio = self.motor.forwardGearRatios[3];
			--[[ ustawienia biegów terenowych --]]
			if this.gearboxSettings.driveModeTerrainIncrease == nil then 
				fieldDriveRatio = self.motor.forwardGearRatios[3]*0.77;
			else
				fieldDriveRatio = self.motor.forwardGearRatios[3]*0.9;
			end;
			self.motor.forwardGearRatios[3] = fieldDriveRatio;
		end;		
		this.gearboxModeCaption.text = this.gearboxSettings.gearboxMode;
		self.currentGear = this.gearboxSettings.currentGear;
		
		
		-- Fuel Light
		local FuelReserve = self.fuelCapacity*8/100;
		if FuelReserve>self.fuelFillLevel then
			this.lightFuelOff.visible = false;
			this.lightFuelOn.visible = true;			
		else 
			this.lightFuelOff.visible = true;
			this.lightFuelOn.visible = false;
		end;
		
		-- Battery Light
		if self.isMotorStarted  then
			this.lightBatteryOff.visible = true;
			this.lightBatteryOn.visible = false;	
		end;
		
		--renderText(0.2, 0.2, 0.04, tostring(self.downForce));
		--renderText(0.2, 0.2, 0.04, tostring(self.movingDirection));
		--renderText(0.2, 0.2, 0.04, tostring(self.maxAccelerationSpeed));
		--renderText(0.2, 0.2, 0.04, tostring(self.motor.forwardGearRatios[3]));
		--WheelsUtil.updateWheelsPhysics(self, dt, currentSpeed, acceleration, doHandbrake, requiredDriveMode);
		--renderText(0.2, 0.2, 0.04, tostring(self.lastAcceleration));
		--renderText(0.2, 0.2, 0.04, tostring(self.wheels[1].axleSpeed));	
		
		self.reverseDriveSoundEnabled = true;
		self.lastAccelerationInDraw = self.lastAcceleration;
	end;	
end;	

function gearboxSpec:onLeave()
	local this = gearboxSpecHelper:getInstance(self.rootNode);
	this.view:setGear('N', true);
	this.gearboxSettings.driveMode = 1;
	this.lightRoad.visible = true;
	this.lightField.visible = false;
end;

function gearboxSpec:draw()
	local this = gearboxSpecHelper:getInstance(self.rootNode);
	if not this:isAI() and self.motor.speedLevel == 0 then this.GearsGaugeWindow:show();
	else 
		this.GearsGaugeWindow:hide();
		if self.isMotorStarted and self.isEntered then
			self.maxAccelerationSpeed 			= this.originalValues.maxAccelerationSpeed;
			self.motor.forwardGearRatios[3] 	= this.originalValues.motor.forwardGearRatios[3];
			self.motor.backwardGearRatio 		= this.originalValues.motor.backwardGearRatio;
		end;
	end;
end;