-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- Gauges Mod
-- Specialization rpm gauge
------------------------------------------------------------*/

-- Model
local name = 'Gauges_Model_rpmGaugeSpecialization';
local _ = newclass(name, Model);
_G[name] = _;

function _:init()
end;

function _:load()
end;


-- Specialization
rpmGaugeSpecHelper = {}
rpmGaugeSpecHelper.SpecInstances = {}

function rpmGaugeSpecHelper:getInstance(index)
	if self.SpecInstances[index] == nil then
		self.SpecInstances[index] = {};
	end;	
	return self.SpecInstances[index];
end;

rpmGaugeSpec = newclass('rpmGaugeSpec');

function rpmGaugeSpec:init()
end;

function rpmGaugeSpec:load(Vehicle, modName)
	if Vehicle ~= nil and tonumber(Vehicle) == nil then
		g_currentMission.controlledVehicle.rpmGaugeSpecializationLoaded = true;
		local this = rpmGaugeSpecHelper:getInstance(Vehicle.rootNode);
		
		this.modName = modName;
		this.Vehicle = Vehicle;

		this.rpmGaugeWindow 				= Mods:getRegistry(this.modName, 'rpmGaugeWindow');
		this.rpmGaugeWindowTip  			= Mods:getRegistry(this.modName, 'rpmGaugeWindowTip');
		this.rpmGaugeWindowC1  				= Mods:getRegistry(this.modName, 'rpmGaugeWindowC1');
		this.rpmGaugeWindowC2  				= Mods:getRegistry(this.modName, 'rpmGaugeWindowC2');
		this.rpmGaugeWindowC3  				= Mods:getRegistry(this.modName, 'rpmGaugeWindowC3');
		this.rpmGaugeWindowC4 				= Mods:getRegistry(this.modName, 'rpmGaugeWindowC4');
		this.rpmGaugeWindowC5				= Mods:getRegistry(this.modName, 'rpmGaugeWindowC5');
		this.rpmGaugeWindowC6 				= Mods:getRegistry(this.modName, 'rpmGaugeWindowC6');
		this.rpmGaugeWindowC7  				= Mods:getRegistry(this.modName, 'rpmGaugeWindowC7');
		this.rpmGaugeWindowC8  				= Mods:getRegistry(this.modName, 'rpmGaugeWindowC8');
		this.rpmGaugeWindowC9  				= Mods:getRegistry(this.modName, 'rpmGaugeWindowC9');
		
		this.rpmGaugeWindowTipMaxWidth 		= 0.196;
		
		function this.rpmTipCaption(num, pos) 
			local mult = 10^(1 or 0)
			--if pos % 2 ~= 0 then
				if num<1 then
					local caption = string.sub(tostring(math.floor(num * mult + 0.5) / mult), 0, 3);
					if string.len(caption) == 1 then caption = caption..'.0' end;
					return caption;
				elseif num>=1 and num <10 then
					local caption = string.sub(tostring(math.floor(num * mult + 0.5) / mult), 0, 3);
					if string.len(caption) == 1 then caption = caption..'.0' end;
					return caption;				
				elseif num>=10 and num<100 then
					local caption = string.sub(tostring(math.floor(num * mult + 0.5) / mult), 0, 4);
					if string.len(caption) == 2 then caption = caption..'.0' end;
					return caption;
				elseif num>=100 and num<1000 then 
					local caption = string.sub(tostring(math.floor(num * mult + 0.5) / mult), 0, 5);
					if string.len(caption) == 3 then caption = caption..'.0' end;
					return caption;
				else return '' end;
			--else return '' end;
		end;
	end;
end;

function rpmGaugeSpec:delete()
end;

function rpmGaugeSpec:mouseEvent(posX, posY, isDown, isUp, button)
end;

function rpmGaugeSpec:keyEvent(unicode, sym, modifier, isDown)
end;

function rpmGaugeSpec:update(dt)
	local this = rpmGaugeSpecHelper:getInstance(self.rootNode);
	
	if self.isMotorStarted and self.isEntered then
		local mult = 10^(3 or 0)
		local rpmTipSegment 		= math.floor(self.motor.maxRpm[3]/9000 * mult + 0.5) / mult;
		this.rpmGaugeWindowC1.text	= this.rpmTipCaption(rpmTipSegment);
		this.rpmGaugeWindowC2.text	= '';
		this.rpmGaugeWindowC3.text	= this.rpmTipCaption(rpmTipSegment*3);
		this.rpmGaugeWindowC4.text	= '';
		this.rpmGaugeWindowC5.text	= this.rpmTipCaption(rpmTipSegment*5);
		this.rpmGaugeWindowC6.text	= '';
		this.rpmGaugeWindowC7.text	= this.rpmTipCaption(rpmTipSegment*7);
		this.rpmGaugeWindowC8.text	= '';
		this.rpmGaugeWindowC9.text	= this.rpmTipCaption(rpmTipSegment*9);
	
		local rpmTipPercentage 			= self.motor.lastMotorRpm*100/self.motor.maxRpm[3];
		local rpmTipWidth				= this.rpmGaugeWindowTipMaxWidth*rpmTipPercentage/100;
		if rpmTipWidth>this.rpmGaugeWindowTipMaxWidth then rpmTipWidth = this.rpmGaugeWindowTipMaxWidth end;
		this.rpmGaugeWindowTip.width 	= rpmTipWidth;
	end;
end;	

function rpmGaugeSpec:draw()
	local this = rpmGaugeSpecHelper:getInstance(self.rootNode);
	
	this.rpmGaugeWindow:show();
end;