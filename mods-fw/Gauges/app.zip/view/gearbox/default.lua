-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- Gauges Mod
-- Gearbox View
------------------------------------------------------------*/

local name = 'Gauges_View_gearbox';
local _ = newclass(name, View);
_G[name] = _;

function _:init()
end;

function _:load()	
	self.controller 		= self:getController();
	self.input 				= Mods:getRegistry(self.ViewPrefix, 'input');
	self.gearboxSettings	= Mods:getRegistry(self.ViewPrefix, 'gearboxSettings');
	self.config 			= Mods:getRegistry(self.ViewPrefix, 'config');	
	
	-- Gears Gauge Widnow
	local window = {
		imagePath 		= self.ViewPrefix..'/images/gears-gauge-window.dds',
		width			= 0.11,
		height			= 0.1,	
		x_pos 			= 0.01,
		y_pos 			= 0.01,		
		disableCursor	= true,
	}
	-- Create Window
	self.GearsGaugeWindow = GraphicLayout(window);
	-- Add captions
	self.gearboxModeCaption = self.GearsGaugeWindow:addCaption(self.gearboxSettings.gearboxMode, 0.008, 0.075, 0.015, nil, true, nil, 'left', true);	
	-- Add Images
	-- Gears
	local gear = {
		width			= 0.024,
		height			= 0.045,	
		x_pos 			= 0.042,
		y_pos 			= 0.026,	
	}
	self.GearD = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/d.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.GearN = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/n.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.GearR = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/r.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.Gear1 = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/1.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.Gear2 = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/2.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.Gear3 = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/3.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.Gear4 = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/4.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.Gear5 = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/5.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.Gear6 = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/6.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.Gear7 = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/7.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.Gear8 = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/8.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	self.Gear9 = self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/gears/9.dds', gear.x_pos, gear.y_pos, gear.width, gear.height);	
	-- RPM Light
	self.rpmLightOff 	= self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/rpm-light-off.dds', 0.014, 0.011, 0.010, 0.015);
	self.rpmLightOn 	= self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/rpm-light-on.dds', 0.014, 0.011, 0.010, 0.015);
	self.rpmLightOn.visible = false;
	--self.rpmLightOn.visible = false;
	-- Drive Mode
	self.lightRoad 		= self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/drive-road.dds', 0.01, 0.035, 0.02, 0.028);
	self.lightField 	= self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/drive-field.dds', 0.01, 0.035, 0.02, 0.028);
	self.lightField.visible = false;
	-- Lights 
	self.lightFuelOff 	= self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/light-fuel-off.dds', 0.08, 0.028, 0.014, 0.022);
	self.lightFuelOn 	= self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/light-fuel-on.dds', 0.08, 0.028, 0.014, 0.022);
	self.lightFuelOn.visible = false;
	self.lightBatteryOff 	= self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/light-battery-off.dds', 0.077, 0.055, 0.02, 0.016);
	self.lightBatteryOn 	= self.GearsGaugeWindow:addImage(self.ViewPrefix..'/images/light-battery-on.dds', 0.077, 0.055, 0.02, 0.016);
	-- Init window
	addModEventListener(self.GearsGaugeWindow);	
	Mods:setRegistry(self.ViewPrefix, 'GearsGaugeWindow', self.GearsGaugeWindow);
	Mods:setRegistry(self.ViewPrefix, 'GearD', self.GearD);
	Mods:setRegistry(self.ViewPrefix, 'GearN', self.GearN);
	Mods:setRegistry(self.ViewPrefix, 'GearR', self.GearR);
	Mods:setRegistry(self.ViewPrefix, 'Gear1', self.Gear1);
	Mods:setRegistry(self.ViewPrefix, 'Gear2', self.Gear2);
	Mods:setRegistry(self.ViewPrefix, 'Gear3', self.Gear3);
	Mods:setRegistry(self.ViewPrefix, 'Gear4', self.Gear4);
	Mods:setRegistry(self.ViewPrefix, 'Gear5', self.Gear5);
	Mods:setRegistry(self.ViewPrefix, 'Gear6', self.Gear6);
	Mods:setRegistry(self.ViewPrefix, 'Gear7', self.Gear7);
	Mods:setRegistry(self.ViewPrefix, 'Gear8', self.Gear8);
	Mods:setRegistry(self.ViewPrefix, 'Gear9', self.Gear9);
	Mods:setRegistry(self.ViewPrefix, 'rpmLightOff', self.rpmLightOff);
	Mods:setRegistry(self.ViewPrefix, 'rpmLightOn', self.rpmLightOn);
	Mods:setRegistry(self.ViewPrefix, 'gearboxModeCaption', self.gearboxModeCaption);
	Mods:setRegistry(self.ViewPrefix, 'lightRoad', self.lightRoad);	
	Mods:setRegistry(self.ViewPrefix, 'lightField', self.lightField);
	Mods:setRegistry(self.ViewPrefix, 'lightFuelOff', self.lightFuelOff);
	Mods:setRegistry(self.ViewPrefix, 'lightFuelOn', self.lightFuelOn);
	Mods:setRegistry(self.ViewPrefix, 'lightBatteryOff', self.lightBatteryOff);
	Mods:setRegistry(self.ViewPrefix, 'lightBatteryOn', self.lightBatteryOn);	
	
	--self:hideGears();
	self:setGear(self.gearboxSettings.currentGear);

	-- Add to LS 2011 mod list
	addModEventListener(self);
end;

function _:loadMap(name)
end;

function _:deleteMap()	
end;

function _:mouseEvent(posX, posY, isDown, isUp, button)
end;

function _:keyEvent(unicode, sym, modifier, isDown)
end;

function _:update(dt)
	self.controller:loadSpecialization();	
	if g_currentMission.controlledVehicle ~= nil then 
		g_currentMission:addExtraPrintText(self.i18n:get('input.startEngine')..': '..self.input:getActionKeyName('input.startEngine'));
	end;

	if g_currentMission.controlledVehicle ~= nil then 
		if g_currentMission.controlledVehicle.isMotorStarted and g_currentMission.controlledVehicle.isEntered then
			-- Key Actions
			if self.input:getAction('input.upGear') then
				self:upGear();
			end;
			if self.input:getAction('input.downGear') then
				self:downGear();
			end;
			if self.input:getAction('input.gearN') then
				self:setGear('N');
			end;
			if self.input:getAction('input.gearR') then
				self:setGear('R');
			end;
			for i=1,self.gearboxSettings.maxGear do
				if self.input:getAction('input.gear'..tostring(i)) then
					self:setGear(i);
				end;
			end;
			if self.input:getAction('input.changeGearboxMode') then
				if self.gearboxSettings.gearboxMode == 'manual' then 
					self.gearboxSettings.gearboxMode = 'auto';
					--[[self.lightRoad.visible = true;
					self.lightField.visible = false;
					self.gearboxSettings.driveMode = 1;--]]
				elseif self.gearboxSettings.gearboxMode == 'auto' then
					self.gearboxSettings.gearboxMode = 'manual';
				end;
				self:setGear('N');
				self.gearboxModeCaption.text = self.gearboxSettings.gearboxMode;
				self.config:setValue('config.gearboxMode', self.gearboxSettings.gearboxMode, 'string');
				self.config:save();		
			end;
			if self.input:getAction('input.changeDriveMode') then
				--if self.gearboxSettings.gearboxMode == 'manual' then
					if self.gearboxSettings.driveMode == 1 then
						self.lightRoad.visible = false;
						self.lightField.visible = true;
						self.gearboxSettings.driveMode = 0;
					elseif self.gearboxSettings.driveMode == 0 then
						self.lightRoad.visible = true;
						self.lightField.visible = false;
						self.gearboxSettings.driveMode = 1;
					end;
				--end;
			end;
		end;
	end;
end;

function _:draw()
	if g_currentMission.controlledVehicle == nil then self.GearsGaugeWindow:hide() end;
	self.lightBatteryOn.visible = true;	
	self.lightBatteryOff.visible = false;
end;

-- Gears Functions
function _:hideGears()
	self.GearD.visible = false;
	self.GearN.visible = false;
	self.GearR.visible = false;
	self.Gear1.visible = false;	
	self.Gear2.visible = false;	
	self.Gear3.visible = false;	
	self.Gear4.visible = false;
	self.Gear5.visible = false;	
	self.Gear6.visible = false;
	self.Gear7.visible = false;
	self.Gear8.visible = false;	
	self.Gear9.visible = false;	
end;

function _:clutchPedal()
	self.gearboxSettings.clutchPedal = false;
	self:hideGears();
	self['Gear'..self.gearboxSettings.currentGear].visible = true;
end;

function _:setGear(gear)
	if not self.gearboxSettings.clutchPedal then
		gear = string.upper(tostring(gear));
		if self['Gear'..gear] ~= nil then
			self:hideGears();
			if self.gearboxSettings.gearboxMode == 'auto' or gear == 'R' or gear == 'N' then self['Gear'..gear].visible = true;
			else self.GearN.visible = true end;
			self.gearboxSettings.currentGear = gear;

			local timerId = addTimer(500, 'clutchPedal', self);
			self.gearboxSettings.clutchPedal = true;
		end;	
	end;
end;

function _:upGear(allowAuto)
	if self.gearboxSettings.gearboxMode == 'manual' or allowAuto then
		local currentGear = self.gearboxSettings.currentGear;
		if currentGear == 'R' then  
			self:setGear('N');
		elseif currentGear == 'N' or currentGear == 'D' then
			self:setGear(1);
		else 
			currentGear = tonumber(currentGear);
			if currentGear<self.gearboxSettings.maxGear then
				self:setGear(currentGear+1);					
			end;
		end;
	end;
end;

function _:downGear(allowAuto)
	if self.gearboxSettings.gearboxMode == 'manual' or allowAuto then
		local currentGear = self.gearboxSettings.currentGear;
		if currentGear == 'N' or currentGear == 'D' or currentGear == 'R' then
			self:setGear('R');
		elseif currentGear == '1' then
			self:setGear('N');
		else 
			currentGear = tonumber(currentGear);
			self:setGear(currentGear-1);					
		end;
	end;
end;

